# Fake-News-Detection
We will check out the news is correct or not.
